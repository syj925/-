-- 添加帖子匿名字段迁移
-- 执行时间: 2025-07-06

-- 为posts表添加is_anonymous字段
ALTER TABLE posts 
ADD COLUMN is_anonymous BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否匿名发布';

-- 添加索引以提高查询性能
CREATE INDEX idx_posts_is_anonymous ON posts(is_anonymous);

-- 验证字段添加成功
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT,
    COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'posts' 
    AND COLUMN_NAME = 'is_anonymous';
