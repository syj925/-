-- 为用户表添加settings字段
-- 执行时间：2025-07-06

-- 添加settings字段到users表
ALTER TABLE users ADD COLUMN settings JSON DEFAULT NULL COMMENT '用户设置JSON数据';

-- 为现有用户初始化默认隐私设置
UPDATE users 
SET settings = JSON_OBJECT(
  'privacy', JSON_OBJECT(
    'anonymousMode', false,
    'allowSearch', true,
    'showLocation', false,
    'allowFollow', true,
    'allowComment', true,
    'allowMessage', true,
    'favoriteVisible', false,
    'followListVisible', true,
    'fansListVisible', true
  )
) 
WHERE settings IS NULL;

-- 添加索引以提高查询性能（可选）
-- CREATE INDEX idx_users_settings ON users ((JSON_EXTRACT(settings, '$.privacy.anonymousMode')));
-- CREATE INDEX idx_users_allow_search ON users ((JSON_EXTRACT(settings, '$.privacy.allowSearch')));

-- 验证数据
SELECT id, username, settings FROM users LIMIT 5;
