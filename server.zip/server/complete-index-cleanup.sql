-- 🔧 校园墙项目完整索引清理脚本
-- ⚠️ 执行前请备份数据库！
-- 📅 生成时间: 2025-09-07T15:37:31.062Z
-- 🎯 目标: 清理所有表的冗余索引

USE campus_community;

-- =====================================================================
-- 🚨 重要提醒: 此脚本将删除 25 个冗余索引
-- =====================================================================

-- 清理 badges 表的冗余索引
DROP INDEX name ON badges; -- 完全重复: (name) 被 (name) 覆盖
DROP INDEX idx_badges_type ON badges; -- 左前缀重复: (type) 被 (type, status) 覆盖

-- 清理 banners 表的冗余索引
DROP INDEX idx_banners_scene ON banners; -- 左前缀重复: (scene) 被 (scene, platform, status) 覆盖

-- 清理 comments 表的冗余索引
DROP INDEX comments_post_id ON comments; -- 左前缀重复: (post_id) 被 (post_id, reply_level, created_at) 覆盖

-- 清理 event_registrations 表的冗余索引
DROP INDEX idx_event_id ON event_registrations; -- 左前缀重复: (event_id) 被 (event_id, user_id) 覆盖

-- 清理 events 表的冗余索引
DROP INDEX idx_status ON events; -- 左前缀重复: (status) 被 (status, start_time) 覆盖

-- 清理 favorites 表的冗余索引
DROP INDEX favorites_user_id ON favorites; -- 左前缀重复: (user_id) 被 (user_id, post_id) 覆盖

-- 清理 follows 表的冗余索引
DROP INDEX follows_follower_id ON follows; -- 左前缀重复: (follower_id) 被 (follower_id, following_id) 覆盖
DROP INDEX follows_follower_id ON follows; -- 左前缀重复: (follower_id) 被 (follower_id, following_id) 覆盖
DROP INDEX follows_following_id_follower_id_unique ON follows; -- 完全重复: (follower_id, following_id) 被 (follower_id, following_id) 覆盖

-- 清理 likes 表的冗余索引
DROP INDEX likes_user_id ON likes; -- 左前缀重复: (user_id) 被 (user_id, target_id, target_type) 覆盖

-- 清理 message_reads 表的冗余索引
DROP INDEX idx_message_reads_user_id ON message_reads; -- 左前缀重复: (user_id) 被 (user_id, message_id) 覆盖

-- 清理 messages 表的冗余索引
DROP INDEX messages_receiver_id ON messages; -- 左前缀重复: (receiver_id) 被 (receiver_id, is_read, created_at) 覆盖

-- 清理 posts 表的冗余索引
DROP INDEX posts_category_id ON posts; -- 左前缀重复: (category_id) 被 (category_id, status, created_at) 覆盖
DROP INDEX posts_status ON posts; -- 左前缀重复: (status) 被 (status, is_top, created_at) 覆盖
DROP INDEX posts_user_id ON posts; -- 左前缀重复: (user_id) 被 (user_id, status, created_at) 覆盖

-- 清理 search_histories 表的冗余索引
DROP INDEX search_histories_user_id ON search_histories; -- 左前缀重复: (user_id) 被 (user_id, keyword) 覆盖

-- 清理 settings 表的冗余索引
DROP INDEX settings_key ON settings; -- 完全重复: (key) 被 (key) 覆盖
DROP INDEX settings_key_unique ON settings; -- 完全重复: (key) 被 (key) 覆盖
DROP INDEX settings_is_system_index ON settings; -- 完全重复: (is_system) 被 (is_system) 覆盖
DROP INDEX settings_key_unique ON settings; -- 完全重复: (key) 被 (key) 覆盖
DROP INDEX settings_type_index ON settings; -- 完全重复: (type) 被 (type) 覆盖

-- 清理 user_badges 表的冗余索引
DROP INDEX idx_user_badges_user_id ON user_badges; -- 左前缀重复: (user_id) 被 (user_id, display_order) 覆盖
DROP INDEX idx_user_badges_user_id ON user_badges; -- 左前缀重复: (user_id) 被 (user_id, is_visible) 覆盖
DROP INDEX idx_user_badges_user_id ON user_badges; -- 左前缀重复: (user_id) 被 (user_id, badge_id) 覆盖



-- =====================================================================
-- 📊 清理完成后验证
-- =====================================================================

SELECT 
    '清理后索引统计' as info,
    TABLE_NAME,
    COUNT(*) as remaining_indexes
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_SCHEMA = 'campus_community'
GROUP BY TABLE_NAME 
ORDER BY remaining_indexes DESC;

-- 显示优化效果
SELECT 
    '优化效果' as result,
    '原索引总数: 124' as before_cleanup,
    '删除冗余: 25' as redundant_removed,
    '预计剩余: 99' as after_cleanup,
    '存储节省: 20.2%' as storage_saved;
