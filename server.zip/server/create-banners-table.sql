-- 创建轮播图表
USE campus_community;

CREATE TABLE IF NOT EXISTS banners (
  id VARCHAR(36) PRIMARY KEY COMMENT '轮播图ID',
  title VARCHAR(100) NOT NULL COMMENT '轮播图标题',
  image VARCHAR(255) NOT NULL COMMENT '轮播图片URL',
  link_type ENUM('url', 'post', 'topic', 'event', 'page') DEFAULT 'url' COMMENT '链接类型',
  link_value VARCHAR(255) COMMENT '链接值',
  target_id VARCHAR(36) COMMENT '目标资源ID',
  scene ENUM('home', 'discover', 'search-main', 'search-topic') DEFAULT 'home' COMMENT '展示场景',
  platform ENUM('app', 'web', 'admin', 'all') DEFAULT 'all' COMMENT '展示平台',
  sort_order INT DEFAULT 0 COMMENT '排序权重',
  priority INT DEFAULT 0 COMMENT '优先级',
  status ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
  start_time TIMESTAMP NULL COMMENT '开始时间',
  end_time TIMESTAMP NULL COMMENT '结束时间',
  click_count INT DEFAULT 0 COMMENT '点击次数',
  view_count INT DEFAULT 0 COMMENT '展示次数',
  tags JSON COMMENT '标签（JSON数组）',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  deleted_at TIMESTAMP NULL COMMENT '删除时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='轮播图表';

-- 创建索引
CREATE INDEX idx_banners_scene_platform_status ON banners(scene, platform, status);
CREATE INDEX idx_banners_sort_priority ON banners(sort_order, priority);
CREATE INDEX idx_banners_time_range ON banners(start_time, end_time);
CREATE INDEX idx_banners_status ON banners(status);
CREATE INDEX idx_banners_scene ON banners(scene);

-- 插入演示数据
INSERT INTO banners (id, title, image, link_type, link_value, scene, platform, sort_order, priority, status) VALUES
('550e8400-e29b-41d4-a716-446655440001', '欢迎来到校园墙', '/uploads/banners/welcome.jpg', 'page', '/pages/about/index', 'home', 'all', 1, 10, 'active'),
('550e8400-e29b-41d4-a716-446655440002', '发现热门话题', '/uploads/banners/topics.jpg', 'page', '/pages/topic/list', 'discover', 'all', 1, 8, 'active'),
('550e8400-e29b-41d4-a716-446655440003', '搜索发现更多', '/uploads/banners/search.jpg', 'page', '/pages/search/index', 'search-main', 'all', 1, 6, 'active'),
('550e8400-e29b-41d4-a716-446655440004', '热门话题推荐', '/uploads/banners/topic-promo.jpg', 'page', '/pages/topic/list', 'search-topic', 'all', 1, 4, 'active');
