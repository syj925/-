-- 添加多级回复支持字段
-- 执行时间：2025-06-28

-- 添加新字段
ALTER TABLE comments 
ADD COLUMN root_comment_id VARCHAR(36) NULL COMMENT '根评论ID，用于快速查找评论树',
ADD COLUMN reply_level INT NOT NULL DEFAULT 0 COMMENT '回复层级：0为顶级评论，1为一级回复，以此类推',
ADD COLUMN reply_count INT NOT NULL DEFAULT 0 COMMENT '回复数量',
ADD COLUMN mentioned_users JSON NULL COMMENT '@提到的用户列表';

-- 添加外键约束
ALTER TABLE comments 
ADD CONSTRAINT fk_comments_root_comment_id 
FOREIGN KEY (root_comment_id) REFERENCES comments(id) ON DELETE SET NULL;

-- 添加索引
CREATE INDEX idx_comments_root_comment_id ON comments(root_comment_id);
CREATE INDEX idx_comments_reply_level ON comments(reply_level);
CREATE INDEX idx_comments_post_level_time ON comments(post_id, reply_level, created_at);

-- 初始化现有数据
-- 1. 设置顶级评论的 reply_level = 0
UPDATE comments SET reply_level = 0 WHERE reply_to IS NULL;

-- 2. 设置一级回复的 reply_level = 1，并设置 root_comment_id
UPDATE comments c1 
SET reply_level = 1, 
    root_comment_id = c1.reply_to
WHERE c1.reply_to IS NOT NULL 
  AND EXISTS (SELECT 1 FROM comments c2 WHERE c2.id = c1.reply_to AND c2.reply_to IS NULL);

-- 3. 设置二级及以上回复的层级和根评论ID
UPDATE comments c1 
SET reply_level = 2,
    root_comment_id = (
        SELECT c2.root_comment_id 
        FROM comments c2 
        WHERE c2.id = c1.reply_to 
          AND c2.reply_level = 1
    )
WHERE c1.reply_to IS NOT NULL 
  AND EXISTS (
      SELECT 1 FROM comments c2 
      WHERE c2.id = c1.reply_to 
        AND c2.reply_level = 1
  );

-- 4. 更新回复数量统计
UPDATE comments c1 
SET reply_count = (
    SELECT COUNT(*) 
    FROM comments c2 
    WHERE c2.reply_to = c1.id 
      AND c2.status = 'normal'
)
WHERE c1.status = 'normal';

-- 验证数据完整性
SELECT 
    reply_level,
    COUNT(*) as count,
    COUNT(CASE WHEN reply_to IS NULL THEN 1 END) as no_parent,
    COUNT(CASE WHEN reply_to IS NOT NULL THEN 1 END) as has_parent,
    COUNT(CASE WHEN root_comment_id IS NULL AND reply_level > 0 THEN 1 END) as missing_root
FROM comments 
WHERE status = 'normal'
GROUP BY reply_level
ORDER BY reply_level;
