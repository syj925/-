-- 清理用户表重复索引的脚本
-- ⚠️ 警告：此操作会删除重复索引，请在维护窗口期间执行
-- 建议先备份数据库

USE campus_community;

-- 1. 保留必要的索引，删除重复的索引

-- 删除重复的username索引（保留第一个）
DROP INDEX username_2 ON users;
DROP INDEX username_3 ON users;
DROP INDEX username_4 ON users;
DROP INDEX username_5 ON users;
DROP INDEX username_6 ON users;
DROP INDEX username_7 ON users;
DROP INDEX username_8 ON users;
DROP INDEX username_9 ON users;
DROP INDEX username_10 ON users;
DROP INDEX username_11 ON users;
DROP INDEX username_12 ON users;
DROP INDEX username_13 ON users;
DROP INDEX username_14 ON users;
DROP INDEX username_15 ON users;
DROP INDEX username_16 ON users;
DROP INDEX username_17 ON users;
DROP INDEX username_18 ON users;
DROP INDEX username_19 ON users;
DROP INDEX username_20 ON users;
DROP INDEX username_21 ON users;

-- 删除重复的phone索引（保留第一个）
DROP INDEX phone_2 ON users;
DROP INDEX phone_3 ON users;
DROP INDEX phone_4 ON users;
DROP INDEX phone_5 ON users;
DROP INDEX phone_6 ON users;
DROP INDEX phone_7 ON users;
DROP INDEX phone_8 ON users;
DROP INDEX phone_9 ON users;
DROP INDEX phone_10 ON users;
DROP INDEX phone_11 ON users;
DROP INDEX phone_12 ON users;
DROP INDEX phone_13 ON users;
DROP INDEX phone_14 ON users;
DROP INDEX phone_15 ON users;
DROP INDEX phone_16 ON users;
DROP INDEX phone_17 ON users;
DROP INDEX phone_18 ON users;
DROP INDEX phone_19 ON users;
DROP INDEX phone_20 ON users;
DROP INDEX phone_21 ON users;

-- 删除重复的email索引（保留第一个）
DROP INDEX email_2 ON users;
DROP INDEX email_3 ON users;
DROP INDEX email_4 ON users;
DROP INDEX email_5 ON users;
DROP INDEX email_6 ON users;
DROP INDEX email_7 ON users;
DROP INDEX email_8 ON users;
DROP INDEX email_9 ON users;
DROP INDEX email_10 ON users;
DROP INDEX email_11 ON users;
DROP INDEX email_12 ON users;
DROP INDEX email_13 ON users;
DROP INDEX email_14 ON users;
DROP INDEX email_15 ON users;
DROP INDEX email_16 ON users;
DROP INDEX email_17 ON users;
DROP INDEX email_18 ON users;
DROP INDEX email_19 ON users;
DROP INDEX email_20 ON users;
DROP INDEX email_21 ON users;

-- 2. 添加必要的新索引
-- 为status字段添加索引（用于用户审核查询）
CREATE INDEX idx_users_status ON users(status);

-- 为常用查询组合添加复合索引
CREATE INDEX idx_users_status_role ON users(status, role);
CREATE INDEX idx_users_created_at ON users(created_at);

-- 3. 验证清理结果
SELECT 
    COUNT(*) as remaining_indexes,
    'After cleanup' as status
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_NAME = 'users' AND TABLE_SCHEMA = 'campus_community';

-- 4. 显示剩余的索引
SELECT 
    INDEX_NAME,
    COLUMN_NAME,
    NON_UNIQUE
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_NAME = 'users' AND TABLE_SCHEMA = 'campus_community'
ORDER BY INDEX_NAME, SEQ_IN_INDEX;
