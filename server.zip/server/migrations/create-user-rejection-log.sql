-- 创建用户拒绝记录表
-- 用于记录被拒绝的注册申请，便于统计和防止恶意注册

CREATE TABLE IF NOT EXISTS user_rejection_logs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL COMMENT '被拒绝的用户名',
  nickname VARCHAR(50) COMMENT '被拒绝的昵称',
  email VARCHAR(100) COMMENT '被拒绝的邮箱',
  rejection_reason TEXT COMMENT '拒绝原因',
  rejected_by INT COMMENT '拒绝操作的管理员ID',
  rejected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '拒绝时间',
  ip_address VARCHAR(45) COMMENT '注册时的IP地址',
  user_agent TEXT COMMENT '注册时的用户代理',
  
  INDEX idx_username (username),
  INDEX idx_rejected_at (rejected_at),
  INDEX idx_rejected_by (rejected_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户注册拒绝记录表';
