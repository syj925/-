-- 创建搜索历史表
CREATE TABLE IF NOT EXISTS `search_histories` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '搜索历史ID',
  `userId` char(36) NOT NULL COMMENT '用户ID',
  `keyword` varchar(100) NOT NULL COMMENT '搜索关键词',
  `type` enum('all','posts','users','topics') NOT NULL DEFAULT 'all' COMMENT '搜索类型',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_search_histories_userId` (`userId`),
  KEY `idx_search_histories_keyword` (`keyword`),
  KEY `idx_search_histories_createdAt` (`createdAt`),
  KEY `idx_search_histories_updatedAt` (`updatedAt`),
  UNIQUE KEY `uk_search_histories_user_keyword_type` (`userId`, `keyword`, `type`),
  CONSTRAINT `fk_search_histories_userId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='搜索历史表';
