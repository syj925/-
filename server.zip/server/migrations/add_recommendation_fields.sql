-- =====================================================
-- 推荐系统重构 - 数据库迁移脚本
-- 目的：添加算法推荐相关字段，简化推荐逻辑
-- 版本：v2.0
-- 日期：2025-01-26
-- =====================================================

-- 开始事务，确保原子性
START TRANSACTION;

-- 1. 检查现有字段（防止重复添加）
-- 如果字段已存在，脚本会跳过添加步骤

-- 2. 添加算法推荐标记字段
ALTER TABLE posts 
ADD COLUMN IF NOT EXISTS auto_recommended BOOLEAN DEFAULT FALSE 
COMMENT '算法自动推荐标记';

-- 3. 添加推荐分数字段
ALTER TABLE posts 
ADD COLUMN IF NOT EXISTS recommend_score DECIMAL(6,2) DEFAULT 0.00 
COMMENT '推荐分数(0-100)，用于排序';

-- 4. 添加分数更新时间字段
ALTER TABLE posts 
ADD COLUMN IF NOT EXISTS score_updated_at TIMESTAMP NULL 
COMMENT '推荐分数最后更新时间';

-- 5. 创建推荐相关索引（提升查询性能）

-- 推荐列表查询索引（主要索引）
CREATE INDEX IF NOT EXISTS idx_posts_recommendation 
ON posts(auto_recommended, recommend_score DESC, created_at DESC);

-- 管理员推荐查询索引
CREATE INDEX IF NOT EXISTS idx_posts_manual_recommend 
ON posts(is_recommended, created_at DESC);

-- 推荐分数更新时间索引（用于定时任务）
CREATE INDEX IF NOT EXISTS idx_posts_score_updated 
ON posts(score_updated_at);

-- 复合推荐索引（包含状态筛选）
CREATE INDEX IF NOT EXISTS idx_posts_recommend_status 
ON posts(status, auto_recommended, is_recommended, recommend_score DESC);

-- 6. 初始化现有数据
-- 将所有手动推荐的帖子设置较高分数，确保优先级
UPDATE posts 
SET 
  recommend_score = 100.00,
  score_updated_at = NOW()
WHERE 
  is_recommended = TRUE 
  AND recommend_score = 0.00;

-- 7. 添加数据一致性约束
-- 推荐分数范围约束
ALTER TABLE posts 
ADD CONSTRAINT chk_recommend_score_range 
CHECK (recommend_score >= 0.00 AND recommend_score <= 100.00);

-- 8. 更新表注释
ALTER TABLE posts 
COMMENT = '帖子表 - 包含算法推荐字段(v2.0)';

-- 提交事务
COMMIT;

-- =====================================================
-- 迁移验证查询
-- =====================================================

-- 检查新字段是否创建成功
SELECT 
  COLUMN_NAME,
  DATA_TYPE,
  IS_NULLABLE,
  COLUMN_DEFAULT,
  COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE 
  TABLE_NAME = 'posts' 
  AND COLUMN_NAME IN ('auto_recommended', 'recommend_score', 'score_updated_at');

-- 检查索引是否创建成功
SHOW INDEX FROM posts WHERE Key_name LIKE '%recommend%';

-- 检查数据初始化情况
SELECT 
  COUNT(*) as total_posts,
  COUNT(CASE WHEN is_recommended = TRUE THEN 1 END) as manual_recommended,
  COUNT(CASE WHEN auto_recommended = TRUE THEN 1 END) as auto_recommended,
  AVG(recommend_score) as avg_score,
  MAX(recommend_score) as max_score
FROM posts 
WHERE status = 'published';

-- =====================================================
-- 回滚脚本（如需回滚）
-- =====================================================
/*
-- 删除添加的字段和索引
DROP INDEX IF EXISTS idx_posts_recommendation ON posts;
DROP INDEX IF EXISTS idx_posts_manual_recommend ON posts;
DROP INDEX IF EXISTS idx_posts_score_updated ON posts;
DROP INDEX IF EXISTS idx_posts_recommend_status ON posts;

ALTER TABLE posts DROP CONSTRAINT IF EXISTS chk_recommend_score_range;
ALTER TABLE posts DROP COLUMN IF EXISTS auto_recommended;
ALTER TABLE posts DROP COLUMN IF EXISTS recommend_score;
ALTER TABLE posts DROP COLUMN IF EXISTS score_updated_at;
*/
