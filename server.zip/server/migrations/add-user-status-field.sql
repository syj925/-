-- 添加用户状态字段的数据库迁移脚本
-- 执行时间：请在维护窗口期间执行

-- 1. 检查是否已存在status字段
SELECT COLUMN_NAME 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'status';

-- 2. 如果不存在，则添加status字段
ALTER TABLE users 
ADD COLUMN status ENUM('active', 'inactive', 'banned') NOT NULL DEFAULT 'active'
AFTER is_disabled;

-- 3. 为现有用户设置默认状态
-- 将所有现有用户设置为active状态（因为他们已经能够正常使用系统）
UPDATE users 
SET status = 'active' 
WHERE status IS NULL OR status = '';

-- 4. 创建索引以提高查询性能
CREATE INDEX idx_users_status ON users(status);

-- 5. 验证迁移结果
SELECT 
    status,
    COUNT(*) as count
FROM users 
GROUP BY status;

-- 迁移完成后的说明：
-- - 所有现有用户状态设为 'active'
-- - 新注册用户将根据系统设置决定初始状态
-- - 管理员可以通过后台审核功能管理用户状态
