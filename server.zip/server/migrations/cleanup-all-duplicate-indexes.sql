-- 全面清理数据库重复索引脚本
-- ⚠️ 警告：此操作会删除重复索引，请在维护窗口期间执行
-- 建议先备份数据库

USE campus_community;

-- 1. 清理 topics 表的重复索引
-- 删除重复的name索引（保留第一个）
DROP INDEX name_2 ON topics;
DROP INDEX name_3 ON topics;
DROP INDEX name_4 ON topics;
DROP INDEX name_5 ON topics;
DROP INDEX name_6 ON topics;
DROP INDEX name_7 ON topics;
DROP INDEX name_8 ON topics;
DROP INDEX name_9 ON topics;
DROP INDEX name_10 ON topics;
DROP INDEX name_11 ON topics;
DROP INDEX name_12 ON topics;
DROP INDEX name_13 ON topics;
DROP INDEX name_14 ON topics;
DROP INDEX name_15 ON topics;
DROP INDEX name_16 ON topics;
DROP INDEX name_17 ON topics;
DROP INDEX name_18 ON topics;
DROP INDEX name_19 ON topics;
DROP INDEX name_20 ON topics;
DROP INDEX name_21 ON topics;

-- 2. 清理 categories 表的重复索引
-- 删除重复的name索引（保留第一个）
DROP INDEX name_2 ON categories;
DROP INDEX name_3 ON categories;
DROP INDEX name_4 ON categories;
DROP INDEX name_5 ON categories;
DROP INDEX name_6 ON categories;
DROP INDEX name_7 ON categories;
DROP INDEX name_8 ON categories;
DROP INDEX name_9 ON categories;
DROP INDEX name_10 ON categories;
DROP INDEX name_11 ON categories;
DROP INDEX name_12 ON categories;
DROP INDEX name_13 ON categories;
DROP INDEX name_14 ON categories;
DROP INDEX name_15 ON categories;
DROP INDEX name_16 ON categories;
DROP INDEX name_17 ON categories;
DROP INDEX name_18 ON categories;
DROP INDEX name_19 ON categories;
DROP INDEX name_20 ON categories;
DROP INDEX name_21 ON categories;
DROP INDEX name_22 ON categories;
DROP INDEX name_23 ON categories;
DROP INDEX name_24 ON categories;
DROP INDEX name_25 ON categories;

-- 3. 检查并清理 comments 表的重复索引
-- 先查看comments表的索引结构
SELECT 'Comments table indexes:' as info;
SELECT INDEX_NAME, COLUMN_NAME 
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_NAME = 'comments' AND TABLE_SCHEMA = 'campus_community'
ORDER BY INDEX_NAME;

-- 4. 验证清理结果
SELECT 'Index cleanup results:' as info;
SELECT 
    TABLE_NAME,
    COUNT(*) as remaining_indexes
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_SCHEMA = 'campus_community'
GROUP BY TABLE_NAME 
ORDER BY remaining_indexes DESC;

-- 5. 显示每个表的索引详情
SELECT 'Detailed index information:' as info;
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    COLUMN_NAME,
    NON_UNIQUE
FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_SCHEMA = 'campus_community'
ORDER BY TABLE_NAME, INDEX_NAME;
