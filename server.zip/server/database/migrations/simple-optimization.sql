-- 简化的数据库优化脚本

-- 1. 添加分类统计字段
ALTER TABLE categories ADD COLUMN post_count INT DEFAULT 0;

-- 2. 添加复合索引
CREATE INDEX idx_posts_category_status_created ON posts(category_id, status, created_at);
CREATE INDEX idx_posts_user_status_created ON posts(user_id, status, created_at);
CREATE INDEX idx_posts_status_top_created ON posts(status, is_top, created_at);

-- 3. 初始化分类帖子计数
UPDATE categories SET post_count = (
    SELECT COUNT(*) 
    FROM posts 
    WHERE posts.category_id = categories.id 
    AND posts.status = 'published'
    AND posts.deleted_at IS NULL
);

-- 4. 添加其他索引
CREATE INDEX idx_comments_post_level_created ON comments(post_id, reply_level, created_at);
CREATE INDEX idx_likes_target_type_created ON likes(target_type, target_id, created_at);

-- 完成
SELECT 'Database optimization completed!' as message;
