-- 数据库优化迁移脚本
-- 添加复合索引和统计字段

-- 1. 添加分类统计字段
ALTER TABLE categories ADD COLUMN post_count INT DEFAULT 0 COMMENT '该分类下的帖子数量';

-- 2. 添加复合索引
-- 分类页面查询优化
CREATE INDEX idx_posts_category_status_created
ON posts(category_id, status, created_at);

-- 用户帖子查询优化
CREATE INDEX idx_posts_user_status_created
ON posts(user_id, status, created_at);

-- 首页查询优化
CREATE INDEX idx_posts_status_top_created
ON posts(status, is_top, created_at);

-- 3. 初始化分类帖子计数
UPDATE categories SET post_count = (
    SELECT COUNT(*) 
    FROM posts 
    WHERE posts.category_id = categories.id 
    AND posts.status = 'published'
    AND posts.deleted_at IS NULL
);

-- 4. 创建触发器自动更新分类帖子计数（MySQL版本）
-- 注意：触发器需要在MySQL命令行中单独执行

-- 5. 添加其他有用的索引
-- 评论查询优化
CREATE INDEX idx_comments_post_level_created
ON comments(post_id, reply_level, created_at);

-- 点赞查询优化
CREATE INDEX idx_likes_target_type_created
ON likes(target_type, target_id, created_at);

-- 用户关注查询优化
CREATE INDEX idx_follows_follower_created
ON follows(follower_id, created_at);

CREATE INDEX idx_follows_following_created
ON follows(following_id, created_at);

-- 6. 分析表以优化查询计划
ANALYZE TABLE posts;
ANALYZE TABLE categories;
ANALYZE TABLE comments;
ANALYZE TABLE likes;
ANALYZE TABLE follows;

-- 完成优化
SELECT 'Database optimization completed successfully!' as message;
