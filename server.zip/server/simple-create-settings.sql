USE campus_community;

CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value TEXT,
  description VARCHAR(255),
  setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
  is_system BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT IGNORE INTO settings (setting_key, setting_value, description, setting_type, is_system) VALUES
('enableSensitiveFilter', 'true', '启用敏感词过滤', 'boolean', true),
('sensitiveWords', '赌博,色情,政治,暴力,诈骗', '敏感词列表', 'string', true),
('sensitiveWordAction', 'replace', '敏感词处理方式', 'string', true),
('dailyPostLimit', '10', '每日发帖限制', 'number', true),
('dailyCommentLimit', '50', '每日评论限制', 'number', true),
('minPostLength', '5', '帖子最小字数', 'number', true),
('maxPostLength', '1000', '帖子最大字数', 'number', true),
('allowAnonymous', 'false', '允许匿名发帖', 'boolean', true),
('enableAudit', 'true', '启用内容审核', 'boolean', true);

SELECT COUNT(*) as total_settings FROM settings;
SELECT * FROM settings WHERE setting_key IN ('enableSensitiveFilter', 'sensitiveWords', 'dailyPostLimit', 'minPostLength', 'maxPostLength');
