-- 手动创建设置表和初始数据
-- 使用前请确认数据库名称正确

USE campus_community;

-- 检查表是否已存在，如果存在则删除（谨慎操作）
-- DROP TABLE IF EXISTS settings;

-- 创建设置表
CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(100) UNIQUE NOT NULL,
  `value` TEXT,
  description VARCHAR(255),
  `type` ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
  is_system BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP NULL
);

-- 插入基础设置数据
INSERT IGNORE INTO settings (`key`, `value`, description, `type`, is_system, created_at, updated_at) VALUES
-- 基础系统设置
('systemName', '校园墙管理系统', '系统名称', 'string', true, NOW(), NOW()),
('logoUrl', 'https://img01.yzcdn.cn/vant/cat.jpeg', '系统Logo', 'string', true, NOW(), NOW()),
('footerText', '© 2023 校园墙管理系统', '页脚文字', 'string', true, NOW(), NOW()),
('icp', '京ICP备12345678号', 'ICP备案号', 'string', true, NOW(), NOW()),

-- 内容设置
('enableAudit', 'true', '是否开启内容审核', 'boolean', true, NOW(), NOW()),
('autoApproveKeywords', '学习,教育,知识,分享', '自动审核通过关键词', 'string', true, NOW(), NOW()),
('autoRejectKeywords', '广告,推广,微信,QQ', '自动审核拒绝关键词', 'string', true, NOW(), NOW()),
('allowAnonymous', 'false', '是否允许匿名发帖', 'boolean', true, NOW(), NOW()),
('dailyPostLimit', '10', '每日发帖限制', 'number', true, NOW(), NOW()),
('dailyCommentLimit', '50', '每日评论限制', 'number', true, NOW(), NOW()),
('minPostLength', '5', '帖子最小字数', 'number', true, NOW(), NOW()),
('maxPostLength', '1000', '帖子最大字数', 'number', true, NOW(), NOW()),
('enableSensitiveFilter', 'true', '内容敏感词过滤', 'boolean', true, NOW(), NOW()),
('sensitiveWordAction', 'replace', '敏感词处理方式', 'string', true, NOW(), NOW()),
('sensitiveWords', '赌博,色情,政治,暴力,诈骗', '敏感词列表', 'string', true, NOW(), NOW()),
('allowImageUpload', 'true', '允许上传图片', 'boolean', true, NOW(), NOW()),
('maxImageSize', '5', '单张图片大小限制(MB)', 'number', true, NOW(), NOW()),
('maxImagesPerPost', '6', '每个帖子最多图片数', 'number', true, NOW(), NOW()),
('allowedImageTypes', '["jpg","jpeg","png"]', '允许的图片格式', 'json', true, NOW(), NOW()),
('maxReplyLevel', '3', '评论最大层级', 'number', true, NOW(), NOW()),

-- 搜索设置
('hotSearchKeywords', '', '热搜关键词', 'string', true, NOW(), NOW()),
('topicBaseWeight', '0.5', '话题基础权重', 'number', true, NOW(), NOW()),
('topicRecentWeight', '0.5', '话题最近权重', 'number', true, NOW(), NOW()),
('topicRecentDays', '7', '话题最近天数', 'number', true, NOW(), NOW()),
('maxHotTopics', '10', '热门话题最大数量', 'number', true, NOW(), NOW()),
('featuredTopicIds', '', '推荐话题ID列表', 'string', true, NOW(), NOW()),

-- 推荐算法设置
('likeWeight', '2.0', '点赞权重', 'number', true, NOW(), NOW()),
('commentWeight', '3.0', '评论权重', 'number', true, NOW(), NOW()),
('collectionWeight', '4.0', '收藏权重', 'number', true, NOW(), NOW()),
('viewWeight', '0.5', '浏览权重', 'number', true, NOW(), NOW()),
('timeDecayDays', '10', '时间衰减天数', 'number', true, NOW(), NOW()),
('maxAgeDays', '30', '最大年龄天数', 'number', true, NOW(), NOW()),
('maxAdminRecommended', '5', '管理员推荐最大数量', 'number', true, NOW(), NOW()),

-- 用户设置
('enableRegister', 'true', '是否开启用户注册', 'boolean', true, NOW(), NOW()),
('requireUserAudit', 'true', '是否需要用户审核', 'boolean', true, NOW(), NOW()),
('defaultRole', 'user', '默认用户角色', 'string', true, NOW(), NOW()),
('avatarSizeLimit', '2', '头像大小限制(MB)', 'number', true, NOW(), NOW());

-- 查看插入的数据
SELECT COUNT(*) as total_settings FROM settings;
SELECT * FROM settings WHERE `key` IN ('enableSensitiveFilter', 'sensitiveWords', 'dailyPostLimit', 'minPostLength', 'maxPostLength') ORDER BY `key`;

-- 显示成功信息
SELECT 'Settings table created and initialized successfully!' as status;
