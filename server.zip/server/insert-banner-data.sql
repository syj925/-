USE campus_community;

-- 清空现有数据（如果有的话）
DELETE FROM banners;

-- 插入演示数据
INSERT INTO banners (id, title, image, link_type, link_value, scene, platform, sort_order, priority, status) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'Welcome to Campus Wall', '/uploads/banners/welcome.jpg', 'page', '/pages/about/index', 'home', 'all', 1, 10, 'active'),
('550e8400-e29b-41d4-a716-446655440002', 'Hot Topics', '/uploads/banners/topics.jpg', 'page', '/pages/topic/list', 'discover', 'all', 1, 8, 'active'),
('550e8400-e29b-41d4-a716-446655440003', 'Search More', '/uploads/banners/search.jpg', 'page', '/pages/search/index', 'search-main', 'all', 1, 6, 'active'),
('550e8400-e29b-41d4-a716-446655440004', 'Topic Recommendations', '/uploads/banners/topic-promo.jpg', 'page', '/pages/topic/list', 'search-topic', 'all', 1, 4, 'active');

-- 查看插入结果
SELECT id, title, scene, status FROM banners;
